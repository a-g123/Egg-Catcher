import pygame

class basket:
    def __init__(self, img=pygame.image.load('images/basket.png'), x=0, y=0):
       
        self.__imgbasket = img
        self.__width = self.__imgbasket.get_width()
        self.__height = self.__imgbasket.get_height()
        self.__xpos = x
        self.__ypos = y

    def get_height(self):
        """returns the height of the image

        Returns:
            height: gives the user the height of the basket
        """        
        return self.__height
    
    def get_width(self):
        """returns the width of the image

        Returns:
            width: gives the user the width of the basket
        """        
        return self.__width     
    
    def get_image(self):
        """returns the image

        Returns:
            img: gives the user the image of the basket
        """        
        return self.__imgbasket
    
    def get_x(self):
        """returns the x position of the image(the top left corner)

        Returns:
            x: the x position of the basket
        """        
        return self.__xpos 

    def get_y(self):
        """returns the y position of the image

        Returns:
            y: the y position of the basket
        """        
        return self.__ypos

    def set_x(self, x):
        """set the x position of the basket(the top left corner)

        Args:
            x (int): the x position
        """        
        self.__xpos = x
    
    def set_y(self, y):
        """set the y position of the basket(the top left corner)

        Args:
            y (int): the y position
        """        
        self.__ypos = y
    
    def set_location(self, x, y):
        """sets the location; x and y position of the image(the top left corner)

        Args:
            x (int): the x position
            y (int): the y position
        """        
        self.__xpos = x
        self.__ypos = y
    
    def get_location(self):
        """gives you the location of the basket

        Returns:
            location: will give you the x and y coordinates of the basket
        """
        return (self.__xpos, self.__ypos)
    
    def movex(self, xpixels):
        """moves the basket along the x position

        Args:
            xpixels (int): the amount of pixels you want the x value to move at a time
        """        
        self.__xpos += xpixels
    
    def get_rectangle(self):
        """returns an invisble rectangular shape of the image - located on the image

        Returns:
            rectange: identifies where on the image you want a collision to occur
        """        
        return pygame.Rect(self.__xpos, self.__ypos, self.__width, 1)

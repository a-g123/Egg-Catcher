import pygame

class egg:
    def __init__(self):
        self.__eggimg = pygame.image.load('images/egg.png')
        self.__crackedeggimg = pygame.image.load('images/cracked_egg.png')
        self.__currentimage = self.__eggimg
        self.__xpos = 0
        self.__ypos = 0
        self.__width = self.__currentimage.get_width()
        self.__height = self.__currentimage.get_height()
        self.__xspeed = 0
        self.__yspeed = 0
        self.__cracked = False

    def cracked(self):
        """cracks the egg and changes the image from a whole egg to a cracked one
        """        
        self.__currentimage = self.__crackedeggimg
        self.__cracked = True
    
    def get_cracked(self):
        """returns the image of the cracked egg

        Returns:
            img: the cracked egg image
        """        
        return self.__cracked

    def get_image(self):
        """returns the image of the whole egg

        Returns:
            img: the whole egg img
        """        
        return self.__currentimage

    def get_width(self):
        """returns the width of the image

        Returns:
            width: the width of the egg
        """        
        return self.__width

    def get_height(self):
        """returns the height of the image

        Returns:
            height: the height of the egg
        """        
        return self.__height

    def get_x(self):
        """returns the x position of the image(the top left corner)

        Returns:
            x: the x position of the egg image
        """        
        return self.__xpos
    
    def get_y(self):
        """returns the y position of the image(the top left corner)

        Returns:
            y: the y position of the egg image
        """        
        return self.__ypos
    
    def set_speed(self, xspeed, yspeed):
        """sets the speed at which the egg moves at

        Args:
            xspeed (int): the x position will move a number of pixels along the x axis based on the xspeed
            yspeed (int): the y position will move a number of pixels along the y axis based on the yspeed
        """        
        self.__xspeed = xspeed
        self.__yspeed = yspeed
        
    def set_yspeed(self, yspeed):
        """sets the speed at which the egg falls at

        Args:
            yspeed (int): the y position will move a number of pixels along the y axis based on the yspeed
        """        
        self.__yspeed = yspeed
    
    def get_speed(self):
        """returns the speed the egg is moving at

        Returns:
            speed: gives the x and y speed of the egg
        """        
        return self.__xspeed, self.__yspeed
    
    def get_yspeed(self):
        """returns the y speed the egg is moving at

        Returns:
            yspeed: gives the y spee of the egg
        """        
        return self.__yspeed

    def move(self):
        """moves the egg based on the x and y speed; depending on the speed that many pixels will move
        """        
        self.__xpos += self.__xspeed
        self.__ypos += self.__yspeed

    def movey(self):
        """move the y position of the egg; depending in the yspeed of the egg
        """        
        self.__ypos += self.__yspeed
        
    def set_x(self, x):
        """sets the x position of the image

        Args:
            x (int): sets the x position the egg image
        """        
        self.__xpos = x
    
    def set_y(self, y):
        """sets the y position of the image

        Args:
            y (int): sets the y position the egg image
        """        
        self.__ypos = y
    
    def set_location(self, pos):
        """sets the location of the image(the top left corner)

        Args:
            pos (int): gives the x and y position
        """        
        self.__xpos = pos[0]
        self.__ypos = pos[1]

    def get_location(self):
        """returns the location of the image

        Returns:
            location: gives the x and y position
        """        
        return (self.__xpos, self.__ypos)
    
    def get_rectangle(self):
        """returns an invisble rectangular shape of the image - located on the image

        Returns:
            rectange: identifies where on the image you want a collision to occur
        """        
        return pygame.Rect(self.__xpos, self.__ypos + 30, self.__width, self.__height - 30)

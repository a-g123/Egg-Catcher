import pygame

class chicken:
    def __init__(self):
        self.__chickenimg = pygame.image.load('images/chicken.png')
        self.__xpos = 0
        self.__ypos = 0
        self.__width = self.__chickenimg.get_width()
        self.__height = self.__chickenimg.get_height()
    
    def get_image(self):
        """returns the image of the chicken

        Returns:
            chicken: the image
        """        
        return self.__chickenimg
    
    def get_xpos(self):
        """return the x position of the image

        Returns:
            x: the x position of the chicken image
        """        
        return self.__xpos
    
    def get_ypos(self):
        """return the y position of the image

        Returns:
            y: the y position of the chicken image
        """        
        return self.__ypos
    
    def get_width(self):
        """return the width of the image

        Returns:
            width: the width of the chicken image
        """        
        return self.__width

    def get_height(self):
        """return the height of the image

        Returns:
            height: the height of the chicken image
        """        
        return self.__height

    def set_x(self, x):
        """set the x position of the image(the top left corner)

        Args:
            x (int): the x postion of the image
        """        
        self.__xpos = x
    
    def set_y(self, y):
        """set the y position of the image(the top left corner)

        Args:
            y (int): the y position of the image
        """        
        self.__ypos = y
    
    def set_location(self, pos):
        """sets the location of the image(the top left corner)

        Args:
            pos (int): gives the x and y position
        """        
        self.__xpos = pos[0]
        self.__ypos = pos[1]

    def get_location(self):
        """returns the location of the image

        Returns:
            location: gives the x and y position of the top left corner of the image
        """        
        return (self.__xpos, self.__ypos)
